package cactusfix.nunyamod.mixin;

import net.minecraft.class_1922;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2266.class)
public class CactusHitboxMixin {

    /**
     * @author CactusFix
     * @reason Overriding the cactus shape to be a full block (16x16x16)
     */
    @Inject(method = "getShape", at = @At("HEAD"), cancellable = true)
    private void forceFullCube(class_2680 state, class_1922 level, class_2338 pos, class_3726 context, CallbackInfoReturnable<class_265> cir) {
        // Shapes.block() returns the standard 1x1x1 cube (equivalent to a full block)
        cir.setReturnValue(class_259.method_1077());
    }
}