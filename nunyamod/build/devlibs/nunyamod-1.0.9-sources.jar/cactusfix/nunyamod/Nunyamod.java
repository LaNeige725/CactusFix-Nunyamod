package cactusfix.nunyamod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Nunyamod implements ModInitializer {
    public static final String MOD_ID = "nunyamod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            // Updated to use net.minecraft.commands.Commands (Mojang Mappings)
            dispatcher.register(Commands.literal("lbcalc")
                .then(Commands.argument("percent", StringArgumentType.word())
                .then(Commands.argument("price", StringArgumentType.word())
                    .executes(context -> {
                        String pStr = StringArgumentType.getString(context, "percent");
                        String vStr = StringArgumentType.getString(context, "price");
                        
                        try {
                            double pct = Double.parseDouble(pStr.replace("%", ""));
                            long val = parseAbbreviatedNumber(vStr);

                            if (val == -1) return 0;

                            long res = (long) (val * (1 - (pct / 100.0)));
                            String resultText = "Offer: " + String.format("%,d", res);
                            
                            // 1.21.11 uses Component.literal() instead of Text.of()
                            context.getSource().sendSuccess(() -> Component.literal(resultText), false);
                            
                        } catch (Exception e) {
                            LOGGER.error("Error calculating offer: ", e);
                            return 0;
                        }
                        return 1;
                    }))));
        });
    }

    private static long parseAbbreviatedNumber(String input) {
        input = input.toLowerCase().trim();
        long mult = 1;
        if (input.endsWith("k")) mult = 1000L;
        else if (input.endsWith("m")) mult = 1000000L;
        else if (input.endsWith("b")) mult = 1000000000L;
        
        if (mult > 1) {
            input = input.substring(0, input.length() - 1);
        }
        
        try {
            return (long) (Double.parseDouble(input) * mult);
        } catch (Exception e) {
            return -1;
        }
    }
}